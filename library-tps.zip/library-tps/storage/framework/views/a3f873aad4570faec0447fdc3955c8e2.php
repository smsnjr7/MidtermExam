<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LibraTrack</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header class="navbar">
        <div class="nav-left">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="LibraTrack Logo" class="logo">
            <h1 class="title">LibraTrack</h1>
        </div>
        <div class="nav-right">
            <a href="<?php echo e(route('borrowers.index')); ?>" class="nav-btn">Borrowers</a>
            <a href="<?php echo e(route('books.index')); ?>" class="nav-btn">Books</a>
            <a href="<?php echo e(route('borrowers.create')); ?>" class="action-btn add-borrower">+ Add Borrower</a>
            <a href="<?php echo e(route('books.create')); ?>" class="action-btn add-book">+ Add Book</a>
        </div>
    </header>

    <main class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="footer">
        <p>&copy; <?php echo e(date('Y')); ?> LibraTrack Library System</p>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\library-tps\resources\views/layouts/app.blade.php ENDPATH**/ ?>