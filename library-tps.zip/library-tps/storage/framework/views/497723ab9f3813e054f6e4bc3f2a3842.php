

<?php $__env->startSection('content'); ?>
<h1>Add Borrower</h1>
<form action="<?php echo e(route('borrowers.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Phone:</label>
    <input type="text" name="phone" required>

    <button class="btn btn-create">Save</button>
    <a href="<?php echo e(route('borrowers.index')); ?>" class="btn btn-back">Back</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\library-tps\resources\views/borrowers/create.blade.php ENDPATH**/ ?>