

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2>Borrowers List</h2>
    <a href="<?php echo e(route('borrowers.create')); ?>" class="btn add-btn">+ Add Borrower</a>
</div>

<?php if($borrowers->isEmpty()): ?>
    <p class="no-data">No borrowers found.</p>
<?php else: ?>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $borrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($borrower->id); ?></td>
                    <td><?php echo e($borrower->name); ?></td>
                    <td><?php echo e($borrower->email); ?></td>
                    <td><?php echo e($borrower->phone); ?></td>
                    <td>
                        <a href="<?php echo e(route('borrowers.edit', $borrower->id)); ?>" class="btn btn-edit">Edit</a>
                        <form action="<?php echo e(route('borrowers.destroy', $borrower->id)); ?>" method="POST" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\library-tps\resources\views/borrowers/index.blade.php ENDPATH**/ ?>