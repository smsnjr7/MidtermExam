

<?php $__env->startSection('content'); ?>
<h2>Edit Borrower</h2>
<form action="<?php echo e(route('borrowers.update', $borrower->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label>Name:</label><input type="text" name="name" value="<?php echo e($borrower->name); ?>" required><br>
    <label>Email:</label><input type="email" name="email" value="<?php echo e($borrower->email); ?>" required><br>
    <label>Phone:</label><input type="text" name="phone" value="<?php echo e($borrower->phone); ?>" required><br>
    <button type="submit">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\library-tps\resources\views/borrowers/edit.blade.php ENDPATH**/ ?>