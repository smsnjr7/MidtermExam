

<?php $__env->startSection('content'); ?>
<h2>Add Book</h2>
<form action="<?php echo e(route('books.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Title:</label><input type="text" name="title" required><br>
    <label>Author:</label><input type="text" name="author" required><br>
    <label>Status:</label>
    <select name="status">
        <option value="Available">Available</option>
        <option value="Borrowed">Borrowed</option>
    </select><br>
    <label>Borrower:</label>
    <select name="borrower_id">
        <option value="">None</option>
        <?php $__currentLoopData = $borrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($borrower->id); ?>"><?php echo e($borrower->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <button type="submit">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\library-tps\resources\views/books/create.blade.php ENDPATH**/ ?>