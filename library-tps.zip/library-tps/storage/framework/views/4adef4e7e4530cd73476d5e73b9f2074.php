

<?php $__env->startSection('content'); ?>
<h2>Books List</h2>
<a href="<?php echo e(route('books.create')); ?>" class="btn">Add Book</a>
<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>Status</th>
        <th>Borrower</th>
        <th>Actions</th>
    </tr>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($book->id); ?></td>
        <td><?php echo e($book->title); ?></td>
        <td><?php echo e($book->author); ?></td>
        <td><?php echo e($book->status); ?></td>
        <td><?php echo e($book->borrower ? $book->borrower->name : '—'); ?></td>
        <td>
            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn">Edit</a>
            <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\library-tps\resources\views/books/index.blade.php ENDPATH**/ ?>