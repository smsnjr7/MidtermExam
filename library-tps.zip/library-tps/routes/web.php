<?php

use App\Http\Controllers\BorrowerController;
use App\Http\Controllers\BookController;

Route::get('/', function () {
    return redirect('/borrowers');
});

Route::resource('borrowers', BorrowerController::class);
Route::resource('books', BookController::class);
