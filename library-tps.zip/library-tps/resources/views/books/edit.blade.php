@extends('layouts.app')

@section('content')
<h2>Edit Book</h2>
<form action="{{ route('books.update', $book->id) }}" method="POST">
    @csrf
    @method('PUT')
    <label>Title:</label><input type="text" name="title" value="{{ $book->title }}" required><br>
    <label>Author:</label><input type="text" name="author" value="{{ $book->author }}" required><br>
    <label>Status:</label>
    <select name="status">
        <option value="Available" {{ $book->status == 'Available' ? 'selected' : '' }}>Available</option>
        <option value="Borrowed" {{ $book->status == 'Borrowed' ? 'selected' : '' }}>Borrowed</option>
    </select><br>
    <label>Borrower:</label>
    <select name="borrower_id">
        <option value="">None</option>
        @foreach($borrowers as $borrower)
        <option value="{{ $borrower->id }}" {{ $book->borrower_id == $borrower->id ? 'selected' : '' }}>
            {{ $borrower->name }}
        </option>
        @endforeach
    </select><br>
    <button type="submit">Update</button>
</form>
@endsection
