@extends('layouts.app')

@section('content')
<h2>Books List</h2>
<a href="{{ route('books.create') }}" class="btn">Add Book</a>
<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>Status</th>
        <th>Borrower</th>
        <th>Actions</th>
    </tr>
    @foreach($books as $book)
    <tr>
        <td>{{ $book->id }}</td>
        <td>{{ $book->title }}</td>
        <td>{{ $book->author }}</td>
        <td>{{ $book->status }}</td>
        <td>{{ $book->borrower ? $book->borrower->name : '—' }}</td>
        <td>
            <a href="{{ route('books.edit', $book->id) }}" class="btn">Edit</a>
            <form action="{{ route('books.destroy', $book->id) }}" method="POST" style="display:inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn">Delete</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>
@endsection
