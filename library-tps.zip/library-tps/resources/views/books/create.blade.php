@extends('layouts.app')

@section('content')
<h2>Add Book</h2>
<form action="{{ route('books.store') }}" method="POST">
    @csrf
    <label>Title:</label><input type="text" name="title" required><br>
    <label>Author:</label><input type="text" name="author" required><br>
    <label>Status:</label>
    <select name="status">
        <option value="Available">Available</option>
        <option value="Borrowed">Borrowed</option>
    </select><br>
    <label>Borrower:</label>
    <select name="borrower_id">
        <option value="">None</option>
        @foreach($borrowers as $borrower)
        <option value="{{ $borrower->id }}">{{ $borrower->name }}</option>
        @endforeach
    </select><br>
    <button type="submit">Save</button>
</form>
@endsection
