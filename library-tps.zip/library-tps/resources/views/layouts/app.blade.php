<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LibraTrack</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <header class="navbar">
        <div class="nav-left">
            <img src="{{ asset('images/logo.png') }}" alt="LibraTrack Logo" class="logo">
            <h1 class="title">LibraTrack</h1>
        </div>
        <div class="nav-right">
            <a href="{{ route('borrowers.index') }}" class="nav-btn">Borrowers</a>
            <a href="{{ route('books.index') }}" class="nav-btn">Books</a>
            <a href="{{ route('borrowers.create') }}" class="action-btn add-borrower">+ Add Borrower</a>
            <a href="{{ route('books.create') }}" class="action-btn add-book">+ Add Book</a>
        </div>
    </header>

    <main class="content">
        @yield('content')
    </main>

    <footer class="footer">
        <p>&copy; {{ date('Y') }} LibraTrack Library System</p>
    </footer>
</body>
</html>
