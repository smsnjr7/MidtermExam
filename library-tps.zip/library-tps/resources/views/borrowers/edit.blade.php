@extends('layouts.app')

@section('content')
<h2>Edit Borrower</h2>
<form action="{{ route('borrowers.update', $borrower->id) }}" method="POST">
    @csrf
    @method('PUT')
    <label>Name:</label><input type="text" name="name" value="{{ $borrower->name }}" required><br>
    <label>Email:</label><input type="email" name="email" value="{{ $borrower->email }}" required><br>
    <label>Phone:</label><input type="text" name="phone" value="{{ $borrower->phone }}" required><br>
    <button type="submit">Update</button>
</form>
@endsection
