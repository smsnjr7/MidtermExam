@extends('layouts.app')

@section('content')
<div class="page-header">
    <h2>Borrowers List</h2>
    <a href="{{ route('borrowers.create') }}" class="btn add-btn">+ Add Borrower</a>
</div>

@if ($borrowers->isEmpty())
    <p class="no-data">No borrowers found.</p>
@else
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($borrowers as $borrower)
                <tr>
                    <td>{{ $borrower->id }}</td>
                    <td>{{ $borrower->name }}</td>
                    <td>{{ $borrower->email }}</td>
                    <td>{{ $borrower->phone }}</td>
                    <td>
                        <a href="{{ route('borrowers.edit', $borrower->id) }}" class="btn btn-edit">Edit</a>
                        <form action="{{ route('borrowers.destroy', $borrower->id) }}" method="POST" class="inline-form">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif
@endsection
