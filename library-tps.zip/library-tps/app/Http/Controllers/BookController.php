<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Borrower;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index()
    {
        $books = Book::with('borrower')->get();
        return view('books.index', compact('books'));
    }

    public function create()
    {
        $borrowers = Borrower::all();
        return view('books.create', compact('borrowers'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'author' => 'required',
            'borrower_id' => 'nullable|exists:borrowers,id',
            'status' => 'required'
        ]);

        Book::create($request->all());
        return redirect()->route('books.index')->with('success', 'Book added successfully!');
    }

    public function edit(Book $book)
    {
        $borrowers = Borrower::all();
        return view('books.edit', compact('book', 'borrowers'));
    }

    public function update(Request $request, Book $book)
    {
        $request->validate([
            'title' => 'required',
            'author' => 'required',
            'borrower_id' => 'nullable|exists:borrowers,id',
            'status' => 'required'
        ]);

        $book->update($request->all());
        return redirect()->route('books.index')->with('success', 'Book updated successfully!');
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->route('books.index')->with('success', 'Book deleted successfully!');
    }
}
